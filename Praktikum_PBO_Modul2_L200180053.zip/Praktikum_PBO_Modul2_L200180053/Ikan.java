public class Ikan{
	String jenis;
	String warna;
	int berat;
	double harga;

	void berijenis(String jenisIkan) {
		jenis = jenisIkan;
	}

	void beriwarna(String warnaIkan) {
		warna = warnaIkan;
	}

	void timbangBerat(int beratIkan) {
		berat = beratIkan;
	}

	void hargaJual(double hargaIkan) {
		harga = hargaIkan;
	}
	
	void infoIkan(){
		System.out.println(
			"Jenis Ikan :" + jenis + "\n" +
			"Warna Ikan :" + warna + "\n" +
			"Berat Ikan :" + berat + "\n" + "Kg" +
			"Harga Ikan : Rp."+ harga);
	}





}
