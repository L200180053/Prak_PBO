public class IkanDemo{
	public static void main(String[] args) {
		Ikan ikan = new Ikan();

		ikan.berijenis("lele");
		ikan.beriwarna("hitam");
		ikan.timbangBerat(145);
		ikan.hargaJual(2000000);
		ikan.infoIkan();
	}
}