public class DosenDemo{
	public static void main(String[] args){
		Dosen dosen = new Dosen();
		dosen.tampilkanNama("Willi susanti");
		dosen.tampilkanNik(200180060);
		dosen.tampilkanPendidikan("S1 Informatika");
		dosen.tampilkanTglLahir("25 September 2019");
		dosen.infoDosen();
	}
}