public class MahasiswaDemo{
	public static void main(String[] args){
		Mahasiswa mahasiswa  = new Mahasiswa();
		mahasiswa.tampilkanNama("Ari Wibowo");
		mahasiswa.tampilkanNim("L200180056");
		mahasiswa.tampilkanAlamat("Purwodadi");
		mahasiswa.jumlahSemester(3);
		mahasiswa.infoMahasiswa();
	}
}