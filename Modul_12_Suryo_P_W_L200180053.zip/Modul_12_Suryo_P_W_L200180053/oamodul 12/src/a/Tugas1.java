package a;

import javax.swing.*;

public class Tugas1 {
    public static void main(String[] args){
        Utama u = new Utama();
        u.setSize(300, 600);
        JLabel Pertanyaan = new JLabel("Modul Praktikum Pemrograman Berorientasi Objek Jelas dan Mudah.");
        JPanel panel = new JPanel();
        panel.add(Pertanyaan);
        String opini[]={"Sangat tidak setuju","Tidak Setuju","Kurang setuju","Setuju","Sangat setuju"};
        JComboBox cb = new JComboBox(opini);
        cb.setBounds(50, 50, 150, 20);
        panel.add(cb);
        u.add(panel);
        u.setSize(500, 300);
        u.setVisible(true);
    }
}