/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

public class Kucing extends pet{
    @Override
    public String perilaku(){
        return "Menyukai Ikan";
    }
    public String suara(){
        return "Meeow..Meeooww";
    }
}
