/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


public class Anjing extends pet{
    @Override
    public String perilaku(){
        return "Menyukai Daging dan Tulang";
    }
    public String suara(){
        return "Guk..Guk..Guk";
    }
}
