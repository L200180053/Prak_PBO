/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LABRPL-21
 */
public class Elang extends Hewan {
    public void jalan(){
     System.out.println("Hewan berjalan pasti memiliki kaki"); 
    }
}
