/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

**
 *
 * @author Asus
 */
public class BankDemo {
    public static void main(String[] args){
        Bank bpr = new BankPribadi();
        Bank bu = new BankUmum();
        Bank bp = new BankPasar();
        Bank bs = new BankSyariah();
        
        System.out.println(
            "Bank Pribadi :"+ bpr.rasioBunga() +"\n"+
            "Bank Umum :"+ bu.rasioBunga() +"\n"+
            "Bank Pasar :"+ bp.rasioBunga() +"\n"+
            "Bank Syariah :"+ bs.rasioBunga()
        );
        BankUmum bkpsr = new BankPasar();
        BankUmum bksyr = new BankSyariah();
        
        System.out.println(
            "Bank Pasar :"+ bkpsr.rasioBunga() +"\n"+
            "Bank Syariah :"+ bksyr.rasioBunga()
        );
    }
}
