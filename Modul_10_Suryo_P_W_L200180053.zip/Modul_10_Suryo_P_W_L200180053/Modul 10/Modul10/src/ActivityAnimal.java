public interface ActivityAnimal {
    public void eat();
    public void travel();
}
