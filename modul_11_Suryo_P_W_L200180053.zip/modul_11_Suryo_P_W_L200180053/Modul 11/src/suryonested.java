/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Asus
 */
public class suryonested {
    String nama = "Suryo Pramuda Wicaksono";
    String NIM = "L200180053";
    
    public void printsuryo(){
        System.out.println(nama + " : " + NIM);
    }
    
    static class newsuryoclass{
        static String jurusan = "informatika";
        public void methodenama(){
            suryonested nested = new suryonested();
            nested.printsuryo();
        }
    }
    class innerclass{
        public void jurusan(){
            suryonested.newsuryoclass nested = new suryonested.newsuryoclass();
            System.out.println("Jurusan : " + nested.jurusan);
        }
    }
}
