/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LABRPL-29
 */
public class OuterDemo {
    int num;
    
    //inner class
    private class InnerDemo{
        private void print(){
            System.out.println("Ini merupakan method inner class by suryo");
        }
    }
    //akses method inner class dari method outer class
    void displayInner(){
        InnerDemo inner = new InnerDemo();
        inner.print();
    }
}
