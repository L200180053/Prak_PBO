/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Latihan;

/**
 *
 * @author LABRPL-29
 */
public class NestedClass {
    String nama = "Hafidh Putra Andhika"; // Lengkapi Nama Saudara
    String nim = "L200180085"; // Lengkapi Dengan Nim Saudara
    
    public void printNama(){
        System.out.println(nama + " : " + nim);
    }
    
    static class StaticNestedClass{
        static String jurusan = "Informatika";
    }
    
    class InnerClass{
        void displayJurusan(){
            StaticNestedClass tampilJurusan = new StaticNestedClass();
            System.out.println("Jurusan = " + tampilJurusan.jurusan);
        }
    }
}
