/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 * @author Personal
 */
public class Main {
   public static void main(String[] args){
        Balok blk = new Balok();
        System.out.println("Luas Permukaan Balok = " + blk.getLuas());
        System.out.println("Volume Balok = " + blk.getVolume()); 
        
        Kubus kbs = new Kubus();
        System.out.println("\nLuas Permukaan Kubus = " + kbs.getLuas());
        System.out.println("Volume Kubus = " + kbs.getVolume()); 
        
        Bola bl = new Bola();
        System.out.println("\nLuas Permukaan Bola = " + bl.getLuas());
        System.out.println("Volume Bola = " + bl.getVolume()); 
        
        Kerucut krc = new Kerucut();
        System.out.println("\nLuas Permukaan Kerucut = " + krc.getLuas());
        System.out.println("Volume Kerucut = " + krc.getVolume());
        
        PrismaSegitiga ps = new PrismaSegitiga();
        System.out.println("\nLuas Permukaan PrismaSegitiga = " + ps.getLuas());
        System.out.println("Volume PrismaSegitiga = " + ps.getVolume()); 
   }
}
