/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 * @author Personal
 */
public class MethodMain {
    public static void main(String[] args){
        Persegi psg = new Persegi();
        System.out.println("Keliling Persegi = " + psg.getKell());
        System.out.println("Luas Persegi = " + psg.getLuas());
        
        PersegiPanjang pp = new PersegiPanjang();
        System.out.println("\nKeliling Persegi Panjang = " + pp.getKell());
        System.out.println("Luas Persegi Panjang = " + pp.getLuas());
        
        JajarGenjang jg = new JajarGenjang();
        System.out.println("\nKeliling Jajar Genjang = " + jg.getKell());
        System.out.println("Luas Jajar Genjang = " + jg.getLuas());
        
        Lingkaran lg = new Lingkaran();
        System.out.println("\nKeliling Lingkaran = " + lg.getKell());
        System.out.println("Luas Lingkaran = " + lg.getLuas());
        
        Segitiga sg = new Segitiga();
        System.out.println("\nKeliling Segitiga = " + sg.getKell());
        System.out.println("Luas Segitiga = " + sg.getLuas());
    }
}
