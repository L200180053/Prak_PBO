/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 * @author Personal
 */
public class JajarGenjang extends methodAbstract {
    int panjang = 12;
    int lebar = 15;
    int alas = 4;
    int tinggi = 3;
    
    @Override
    public int luas(){
        return alas*tinggi;
    }
    @Override
    public int keliling(){
        return 2*(panjang+lebar);
    }
}
