/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 * @author Personal
 */
public class Bola extends methodAbstrak {
    int jari = 14;
    
    public int luasPermukaan(){
        return (22/7)*4*jari*jari;
    }
    public int volume(){
        return (22/7)*(4/3)*jari*jari*jari;
    }
}
