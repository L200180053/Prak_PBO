/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 * @author Personal
 */
public class Kerucut extends methodAbstrak {
    int jari = 7;
    int sisi = 3;
    int tinggi = 4;
    
    public int luasPermukaan(){
        return 22/7*jari*(jari+sisi);
    }
    public int volume(){
        return (int) (0.3*3.14*jari*jari*tinggi);
    }
}
